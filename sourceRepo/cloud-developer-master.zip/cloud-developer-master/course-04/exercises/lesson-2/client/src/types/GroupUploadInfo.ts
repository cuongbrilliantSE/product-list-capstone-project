export interface GroupUploadInfo {
  name: string
  description: string
}
