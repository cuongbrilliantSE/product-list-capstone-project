
import { CustomAuthorizerEvent, CustomAuthorizerResult } from 'aws-lambda'
import 'source-map-support/register'

export const handler = async (event: CustomAuthorizerEvent): Promise<CustomAuthorizerResult> => {
  return null
}
