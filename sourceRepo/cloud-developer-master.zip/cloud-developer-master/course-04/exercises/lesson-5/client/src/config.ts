export const apiEndpoint = '...'

export const authConfig = {
  domain: '...',
  clientId: '...',
  callbackUrl: 'http://localhost:3000/callback'
}
