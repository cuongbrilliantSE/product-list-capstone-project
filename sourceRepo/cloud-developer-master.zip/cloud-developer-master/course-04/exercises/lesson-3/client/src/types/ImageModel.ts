export interface ImageModel {
  groupId: string
  timestamp: string
  title: string
  imageId: string
  imageUrl: string
}
