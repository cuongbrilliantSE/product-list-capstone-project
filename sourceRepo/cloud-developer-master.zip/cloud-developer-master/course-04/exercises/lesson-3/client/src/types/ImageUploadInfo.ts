export interface ImageUploadInfo {
  groupId: string,
  title: string
}
